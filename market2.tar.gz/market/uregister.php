<?php

    include("database.php");
  $cedula=$_POST['cedula'];
    $firstname=$_POST['uname'];
    $lastname=$_POST['ulastname'];
	$gender = $_POST['gender'];
		$email=$_POST['uemail'];
		$pswd=$_POST['pswd'];
		$pswd2=$_POST['pswd2'];
		




	if ($gender == "M")
		$photo = "images/boy.png";
	elseif	($gender == "F")
		$photo = "images/girl.png";
	else
		$photo = "images/img_default.png";
		

		if($_POST["pswd"]==$_POST["pswd2"])

			{
				



			$pswd=password_hash($_POST['pswd'],PASSWORD_DEFAULT);
			//1. Create query
			$sql_validation = "SELECT * FROM usuarios WHERE email = '$email' ";
			//2. Execute query
			$result=$conn->query($sql_validation);
		//validacion cedula
		
			$sql_validation2 = "SELECT * FROM usuarios  WHERE cedula = '$cedula' ";
			//2. Execute query
			$result2=$conn->query($sql_validation2);
			//3. Validation
			if($result->num_rows == 0 and $result2->num_rows == 0){
				$sql="INSERT INTO usuarios (cedula, firstname, lastname,email, password,photo) VALUES('$cedula','$firstname','$lastname','$email','$pswd','photo_url_db')";
				
				if ($conn->query($sql)===true) {
					
			echo "<script language='javascript'>alert('Usuario regisrado con exito')</script>";
			header("Refresh:0;url=login.php");


			

			$file_name = $_FILES['photo']['name'];//get file name
			$file_type = $_FILES['photo']['type'];//get file type
			$file_size = $_FILES['photo']['size']/1024;//get file defaul: kb
			$file_tmp = $_FILES['photo']['tmp_name'];
			//echo $idNumber."<br>".$file_name."<br>".$file_type."<br>".$file_size."<br>".$file_tmp;
			move_uploaded_file( $_FILES['photo']['tmp_name'],"photos/".$_FILES['photo']['name']);
			$photo_url_db = "photos/".$_FILES['photo']['name'];
		
				}else{
					echo "Error:".$sql."<br>".$conn->error;
				}
			}else{
				echo "<script language='javascript'>alert('Usuario ya existe')</script>";
				header("Refresh:0;url=signup.php");
			}
					
			}else{				
			echo "<script language='javascript'>alert('Contraseña no son iguales')</script>";
			header("window.location; url=signup.php");
			

			}



?>
